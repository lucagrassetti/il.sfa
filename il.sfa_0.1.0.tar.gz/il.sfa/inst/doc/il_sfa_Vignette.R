## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(il.sfa)

## -----------------------------------------------------------------------------
N <- 100
T <- 5
para <- c(1,-1.5,1,0.25)
dat <- DGP(N, T, list(beta=para[1], sigmav=para[4], gamma=para[2:3]), model = "Exp",
           seed.val = 22, nsim = 10)

## -----------------------------------------------------------------------------
mydat <- list(y = dat$daty[1,], x = data.frame(dat$x), g = dat$g, z = dat$datz)

## -----------------------------------------------------------------------------
mle <- il_sfa(X = mydat$x, y = mydat$y, distr = "Exp", het = TRUE, z = mydat$z,
              group = mydat$g, useHess = TRUE)
mle

## -----------------------------------------------------------------------------
mydat <- list(y = dat$daty[5,], x = data.frame(dat$x), g = dat$g, z = dat$datz)
mle <- il_sfa(X = mydat$x, y = mydat$y, distr = "Exp", het = TRUE, z = mydat$z,
              group = mydat$g, useHess = TRUE)
mle

## -----------------------------------------------------------------------------
mle <- il_sfa(X = mydat$x, y = mydat$y, distr = "HN", het = TRUE, z = mydat$z,
              group = mydat$g, useHess = TRUE)
mle

## -----------------------------------------------------------------------------
N <- 100
T <- 5
para <- c(1,-1.5,1,0.25)
nsimul <- 1000
dat <- DGP(N, T, list(beta=para[1], sigmav=para[4], gamma=para[2:3]), model = "Exp",
           seed.val = 22, nsim = nsimul)

## ---- cache = TRUE------------------------------------------------------------
res100 <- matrix(0, nrow = nsimul, ncol=4)
for(i in 1:nrow(res100)){
#  print(i)
  mydat <- list(y = dat$daty[i,], x = data.frame(dat$x), g = dat$g, z = dat$datz)
  mle <- il_sfa(X = mydat$x, y = mydat$y, distr = "Exp", het = TRUE, z = mydat$z,
                group = mydat$g, useHess = TRUE)
  res100[i,] <- mle$par
  }

## -----------------------------------------------------------------------------
for(i in 1:4) print(MSE(res100[,i], para[i]))

## ---- cache = FALSE-----------------------------------------------------------
  data(res_N100_Stata)
  for(i in 1:4) print(MSE(res_N100_Stata[1:nsimul,i], para[i]))

