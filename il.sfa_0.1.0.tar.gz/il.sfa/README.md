# il.sfa

Software companion for the estimation of TFE SFM with an Integrated Likelihood Approach. The source code is given with the typical structure of a package, and the built package can be easily downloaded as a

- Source file: il.sfa_0.1.0.tar.gz 
- Binary file: il.sfa_0.1.0.tgz 

and installed locally.
